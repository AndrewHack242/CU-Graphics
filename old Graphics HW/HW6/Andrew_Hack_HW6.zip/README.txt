Andrew Hack, HW6

Time spent: 6 hours

compiling: make

----KEYBINDS

arrows: rotate screen (both in first person and not)
wasd: movement in first person
c: move down (according to camera orientation)
spacebar: move up (according to camera orientation)

q: swap between perspective and orthogonal

f: swap between first person and aerial view

page up & page down: change dimensions of space

e: toggle light
m: switch the light mode between auto-move and self-move
, and . (or < and >): move the light around the center if on self-move
1 and 2: move the light down or up

x: toggles the spinning of top cube



ESCAPE: quit


----CODE REUSE:
Code started as a straight copy of my HW5 project
all code is original, but some ideas were gotten from ex14/15



----OTHER NOTES:
THESE TEXTURES ARE NOT MY OWN
ALL TEXTURES WERE BORROWED FROM THE VIDEO GAME PORTAL 2

