Andrew Hack, HW4

Time spent: 6 hours

compiling: make

----KEYBINDS

arrows: rotate screen (both in first person and not)
wasd: movement in first person
c: move down (according to camera orientation)
spacebar: move up (according to camera orientation)

q: swap between perspective and orthogonal

f: swap between first person and aerial view

page up & page down: change dimensions of space

ESCAPE: quit


----CODE REUSE:
Code started as a straight copy of my HW3 project, which was an edit of my lorenz project and was edited from there.
Borrowed some functions / ideas from ex8

from lorenz project:
	all code re-use is commented in the code, some code is re-used from gears,from ex5, and from ex7.



----OTHER NOTES:
I made a bit of an assumption:
the program will start with an aerial view that you can use to try out the two perspectives, but it will also still allow you to change your camera angle around the cube. You are not completely locked in place.
first person movement is still different though, first person movement allows you to move freely in three dimensions.
