Andrew Hack, HW5

Time spent: 6 hours

compiling: make

----KEYBINDS

arrows: rotate screen (both in first person and not)
wasd: movement in first person
c: move down (according to camera orientation)
spacebar: move up (according to camera orientation)

q: swap between perspective and orthogonal

f: swap between first person and aerial view

page up & page down: change dimensions of space

e: toggle light
m: switch the light mode between auto-move and self-move
, and . (or < and >): move the light around the center if on self-move
1 and 2: move the light down or up

x: toggles the spinning of top cube



ESCAPE: quit


----CODE REUSE:
Code started as a straight copy of my HW4 project, but was broken out into seperate files for neatness before I began work on lighting
Borrowed some functions / ideas from ex13



----OTHER NOTES:
Please move the light up or down using 1 or 2.
Also, some of the faces feel weird to look at due to the nature of the companion's shape.
There are no shadows, and as such, anything facing inward at all feels kind of weird to look at as the light may be 'passing' right through the bulk of the cube.
All of the normals, however, are correct.

