Andrew Hack, HW7

Time spent: 1 hour (This was a crazy busy week)

compiling: make
running: ./hw7

----KEYBINDS

0: restart pattern

esc: exit program


----CODE REUSE:
Code began as ex015

----OTHER NOTES:
Using Textures to store what pixels on the screen are 1's and 0's - made Rule 110, a cellular automaton