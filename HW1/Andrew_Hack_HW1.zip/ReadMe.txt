Andrew Hack, HW1

Time spent: 1 hour not including setting up the opengl environment

compiling: make

----KEYBINDS

arrows: rotate around scene

p: swap between perspective and orthogonal

m: toggle rgb shader

page up & page down: change dimensions of space

esc: exit program


----CODE REUSE:
Code is very similar to your ex1, started as a copy. Modified projection space, added my own companion cubes instead of the simple box, and made the required shader.


----OTHER NOTES:
I got each shader down to 1-2 lines of actual code. The effect is more pronounced in orthogonal mode.