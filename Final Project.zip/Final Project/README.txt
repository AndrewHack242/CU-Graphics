Andrew Hack, final checkup

You don't need to run it, there isn't much to see.

compiling: make
running: ./final

I AM RUNNING BEHIND - plain and Simple

What is done: all of the "functionality"

What needs to be done: 
create objects
	-create the shaders for effects on these objects (infrastructure for using them is already setup)
	-create/find textures to apply
actually build the scene files out using the objects

It is a lot of work and I am aware that there is not much feedback you can give me right now.