Andrew Hack, HW4

Time spent: 4 hours

running: 
run local server in directory (if you have python 3, then 'python3 -m http.server' will do the trick)
open the .html file with the browser of your choice (I tested the project in chrome)

----Controls

mouse + drag: rotate the scene

move slider up/down: change light height


----CODE REUSE:
Code began as ex07

----OTHER NOTES:
I added lighting, but felt that I wanted to do something specific to webGL,
so I added a slider on the right that can be used to change the light height.
This uses a little html, a little CSS, and a little javascript, so it was good 
practice and let me shake off the rust with those things.